# PagoMovilFast — APK con GitHub Actions

App Android que envuelve la calculadora `descarga.html` en un WebView. Funciona sin conexión
(solo la consulta de la tasa BCV usa internet) y guarda los datos en el teléfono.

## Contenido

| Archivo | Qué es |
|---|---|
| `app/src/main/assets/descarga.html` | La app: calculadora, IGTF, comisión, datos e historial |
| `app/src/main/java/com/pagomovilfast/app/MainActivity.java` | Contenedor WebView (pantalla completa, botón atrás, exportar a Descargas) |
| `.github/workflows/build-apk.yml` | Compila el APK en la nube (GitHub Actions) |
| `app/build.gradle`, `settings.gradle`, `build.gradle` | Configuración de Android |

---

## Pasos para obtener el APK (sin instalar nada en tu PC)

### 1. Crea el repositorio

1. Entra en <https://github.com/new>
2. Nombre: `pagomovilfast` (puede ser **privado**).
3. **No** marques “Add a README”, ni `.gitignore`, ni licencia.
4. Pulsa **Create repository**.

### 2. Sube el proyecto

1. En el repo vacío, pulsa **Add file → Upload files**.
2. Arrastra **todo el contenido** de esta carpeta (no la carpeta en sí):
   - `app/`
   - `.github/`
   - `settings.gradle`
   - `build.gradle`
   - `gradle.properties`
   - `.gitignore`
3. Pulsa **Commit changes**.

> **Importante:** `settings.gradle` debe quedar en la **raíz** del repositorio y el workflow en
> `.github/workflows/build-apk.yml`.
>
> Si tu navegador no muestra la carpeta `.github` (empieza por punto, está oculta), usa
> **Add file → Create new file**, escribe como nombre `.github/workflows/build-apk.yml`
> y pega el contenido del archivo del proyecto.

### 3. Espera la compilación

1. Ve a la pestaña **Actions**.
2. Verás la ejecución **“Compilar APK”** (tarda unos 3–6 minutos).
3. Si no arranca sola: entra en **Compilar APK → Run workflow**.

### 4. Descarga e instala

1. Abre la ejecución terminada (check verde).
2. Al final de la página, en **Artifacts**, descarga **PagoMovilFast-apk**.
3. Se baja un ZIP: descomprímelo y obtendrás **`PagoMovilFast.apk`**.
4. Pasa el APK al teléfono (cable, WhatsApp, Drive…) e instálalo.
   Android pedirá permitir “instalar apps desconocidas” para esa aplicación; es normal.

---

## Notas

- El APK es de tipo **debug**, firmado automáticamente. Sirve para uso personal;
  para publicar en Play Store habría que crear una firma de release.
- Internet solo se usa para consultar la tasa del BCV; el resto funciona sin conexión.
- Los montos, tus datos y el historial se guardan en el almacenamiento del teléfono.
- Para actualizar la app: sube los cambios y descarga el nuevo artifact. Instala encima la
  versión nueva (misma firma) o desinstala la anterior primero.

## Si algo falla

- **No aparece el workflow:** Settings → Actions → General → “Allow all actions and reusable workflows”.
- **Falla “Compilar el APK”:** abre el log. Lo más común es que falte `settings.gradle` en la raíz
  o que la carpeta `.github` no se haya subido.
- **Falla al instalar:** desinstala una versión anterior si cambió la firma.
