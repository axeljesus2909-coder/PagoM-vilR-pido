package com.pagomovilfast.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Contenedor nativo de PagoMovilFast.
 * Carga la calculadora local (assets/descarga.html) en un WebView sin barra de navegador.
 */
public class MainActivity extends Activity {

    private static final String APP_URL = "file:///android_asset/descarga.html";
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.parseColor("#059669"));
        window.setNavigationBarColor(Color.parseColor("#047857"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#EEF2F7"));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        /* La pagina se carga desde file:///android_asset: sin esto el WebView bloquea
           las peticiones CORS a la API del BCV y el boton de actualizar nunca funciona.
           Deprecados desde API 30, pero funcionales y seguros aqui: solo se carga
           contenido propio de la app, no URLs remotas ni archivos del usuario. */
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AppBridge(), "PMFAndroid");

        setContentView(webView);
        webView.loadUrl(APP_URL);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.removeJavascriptInterface("PMFAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /**
     * Puente JavaScript -> Android para exportar el registro diario.
     * En Android 10+ guarda en Descargas con MediaStore (sin permisos);
     * en versiones anteriores usa la carpeta privada de la app.
     */
    private class AppBridge {

        @JavascriptInterface
        public boolean copyToClipboard(String text) {
            try {
                ClipboardManager manager =
                        (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (manager == null) {
                    return false;
                }
                manager.setPrimaryClip(ClipData.newPlainText("PagoMovilFast", text));
                return true;
            } catch (Exception err) {
                return false;
            }
        }

        /** Abre la hoja de compartir de Android (WhatsApp, Telegram, correo, etc.). */
        @JavascriptInterface
        public boolean shareText(final String text) {
            try {
                final Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, "Datos Pago Móvil");
                send.putExtra(Intent.EXTRA_TEXT, text);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(Intent.createChooser(send, "Compartir datos de Pago Móvil"));
                        } catch (Exception err) {
                            /* No hay apps para compartir instaladas */
                        }
                    }
                });
                return true;
            } catch (Exception err) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean saveTextFile(String fileName, String content) {
            String safeName = sanitize(fileName);
            if (safeName.isEmpty()) {
                safeName = "pago-movil.txt";
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    return saveWithMediaStore(safeName, content);
                }
                return saveToAppFolder(safeName, content);
            } catch (Exception err) {
                return false;
            }
        }

        private boolean saveWithMediaStore(String name, String content) throws Exception {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) {
                return false;
            }

            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out == null) {
                return false;
            }
            try {
                out.write(content.getBytes(StandardCharsets.UTF_8));
                out.flush();
            } finally {
                out.close();
            }
            return true;
        }

        private boolean saveToAppFolder(String name, String content) throws Exception {
            File dir = getExternalFilesDir(null);
            if (dir == null) {
                dir = getFilesDir();
            }
            File file = new File(dir, name);
            FileOutputStream out = new FileOutputStream(file);
            try {
                out.write(content.getBytes(StandardCharsets.UTF_8));
                out.flush();
            } finally {
                out.close();
            }
            return true;
        }

        private String sanitize(String name) {
            if (name == null) {
                return "";
            }
            return name.replace("/", "_").replace("\\", "_").replace("..", "_").trim();
        }
    }
}
